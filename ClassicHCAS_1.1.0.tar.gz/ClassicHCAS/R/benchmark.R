#' Condition benchmarking of target points
#'
#' The HCAS (Habitat Condition Assessment System) benchmarking function evaluates habitat
#' condition by comparing observed and predicted remote sensing (RS) variables. It integrates
#' multiple RS data layers to provide a comprehensive assessment of habitat quality and changes
#' over time. This function is designed to help researchers and conservationists quantify the
#' impacts of environmental changes and management interventions on habitat condition.
#'
#' Ensure that the order of remote sensing variables is consistent between predicted and observed inputs
#' (for both raster and matrix formats). The RS variable values must be centered and scaled
#' prior to prediction. Failure to do so may result in variables with larger ranges having
#' disproportionate influence in the multi-dimensional distance calculations.
#'
#' This function uses an integer-based distance checks for fast radius searches on either
#' geographic or projected coordinates. In geographic mode, coordinates are
#' stored in micro-degrees (degree * 1000_000) and the distance is approximated by:
#'
#'     distance² ≈ (dlat)² + (dlon × cos(lat₁))²
#'
#' where cos(lat₁) is derived from the query latitude. This avoids floating-
#' point overhead and provides substantial performance gains but introduces
#' distortion at larger distances. For applications requiring higher accuracy,
#' especially beyond regional scales (more than several 100s of kilometers in \code{radius_km}),
#' use a projected coordinate system so distances in meters can be evaluated directly.
#'
#' Ensure that \href{https://en.wikipedia.org/wiki/OpenMP}{OpenMP} is installed on your system
#' to take advantage of parallel processing and accelerate computations. While most systems
#' include OpenMP by default, you may need to load the appropriate module if you're using an HPC
#' system.
#'
#' \strong{Note for macOS users:} Install OpenMP via Homebrew with \code{brew install libomp}
#' before installing this package.
#'
#' Note that the default parameters are tailored for Australia and may not be suitable for other
#' regions.
#'
#' @inheritParams ref_density
#' @param samples A matrix or data.frame containing x, y, predicted-RS, and observed-RS values
#' (in that specific order) for benchmark samples (also known as reference sites). If the
#' \code{data} argument is a SpatRaster, you can provide only the x and y coordinates of the
#' benchmark samples. In this case, the corresponding values will be extracted from the raster
#' layers. Consider extra time for sample value extraction in this case.
#' @param ref_density A matrix or \strong{reference_density} object of normalised HCAS
#' reference density (see \code{\link{ref_density}} and \code{\link{normalise}}).
#' @param xy_stats A vector, mean and standard deviation of coordinates for centre and
#' scaling the coordinate to use as a penalty. The order should be: mean(x), mean(y), sd(x), sd(y).
#' This argument helps achieving consistent results when running benchmarking over multiple tiles.
#' @param xy_penalty Numeric. The spatial distance penalty value for selecting benchmark points.
#' The higher the value the more penalise the distant location will be. The value 0 means no penalty.
#' @param radius_km Numeric. Search radius in kilometers for considering benchmark samples.
#' See details section for more information on distance calculation.
#' @param k_pred Integer. Number of nearest predicted RS samples to take.
#' @param k_obs Integer. Number of nearest observed RS sample to takes.
#' @param bin_width Numeric. Specifies the bin width of the reference density. If \code{ref_density} is
#' a \strong{reference_density} object, this value can be read from its attributes and may be left \code{NULL}.
#' The bin width must be consistent between the reference density creation and the benchmarking step to
#' ensure condition is accurately calculated.
#' @param interpolate Logical. Whether to interpolate the reference density for a smoother result.
#' @param offset Integer. Specifies the number of reference density bins that were ignored during
#' normalisation (see \code{\link{normalise}}). If \code{ref_density} is a \strong{reference_density} object,
#' this value can be read from its attributes and may be set \code{NULL}. Similar to bin-width,
#' the \code{offset} must be consistent between the reference density normalisation and the benchmarking
#' step to ensure condition is accurately calculated.
#' @param confidence Numeric. The confidence value for LDC methods. See details below..
#' @param lambda Numeric. The lambda param for LDC Cauchy weighting...
#' @param exclude_slef Logical. To exclude a benchmark point from assessing itself.
#' @param drop_features Integer vector. Completely remove RS variables from the benchmarking process.
#' Positions are 1-based within the RS feature set, not the full input column order. For
#' consistency, it is recommended to exclude the same variables used in the reference density step; unless
#' you have a specific reason not to.
#' @param make_su Logical. To make the uncertainty map or not.
#' @param ... Additional arguments for writing raster outputs e.g. \code{filename},
#' \code{overwrite}, and \code{wopt} from terra \code{\link[terra]{predict}}.
#'
#' @seealso \code{\link{ref_density}}, \code{\link{normalise}}, and \code{\link{calibrate}}
#'
#' @return A matrix or SpatRaster, depending on the inputs.
#' @export
#'
#' @examples
#' \donttest{
#' library(ClassicHCAS)
#'
#'
#'
#' }
benchmark <- function(
        data,
        samples,
        ref_density,
        xy_stats = c(0, 0, 1, 1),
        xy_penalty = 0.0,
        radius_km = 200,
        k_pred = 50,
        k_obs = 20,
        bin_width = NULL,
        interpolate = TRUE,
        offset = 0,
        confidence = 0.5,
        lambda = 2.0,
        exclude_slef = TRUE,
        drop_features = NULL,
        make_su = FALSE,
        num_threads = -1,
        ...) {

    # check k_pred and k_obs
    if (k_pred < k_obs) stop("'k_obs' must be smaller or equal to 'k_pred'.")
    # check samples and reference density
    samples <- if (.is_mat(samples)) .check_mat(samples) else stop("'samples' must be a matrix or convertible to one.")
    ref_density <- if (.is_mat(ref_density)) .check_mat(ref_density) else stop("'ref_density' must be a matrix or convertible to one.")
    if (nrow(ref_density) != ncol(ref_density)) warning("Reference density dimensions are not equal!\n")

    if (methods::is(ref_density, "reference_density")) {
        # check for reference density bin_width consistency
        if (is.null(bin_width)) {
            bin_width <- attributes(ref_density)$bin.width
        } else {
            if (bin_width != attributes(ref_density)$bin.width) {
                warning("Provided 'bin_width' differs from reference density attribute.")
            }
        }
        # check for reference density offset consistency
        if (is.null(offset)) {
            offset <- attributes(ref_density)$offset
        } else {
            if (offset != attributes(ref_density)$offset) {
                warning("Provided 'offset' differs from reference density attribute.")
            }
        }
    }

    # interpolate reference density
    if (interpolate) {
        ref_density <- terra::as.matrix(
            terra::disagg(terra::rast(ref_density), fact = 2, method = "bilinear"),
            wide = TRUE
        )
        # update the binwidth and offset
        bin_width <- bin_width / 2
        offset <- offset * 2
    }
    # get the bin number after interpolation
    bin_num <- min(dim(ref_density))

    if (.is_mat(data)) {
        # check and convert to matrix
        data <- .check_mat(data)

        if (ncol(samples) != ncol(data)) {
            stop("Samples must include all raster values (matching column count with 'data').")
        }

        keep_features <- .keep_rs_features(drop_features, .num_rs_vars_mat(samples, "samples"))
        samples <- .subset_rs_mat(samples, keep_features)
        data <- .subset_rs_mat(data, keep_features)

        tryCatch(
            {
                output <- .benchmarking(
                    model = list(),
                    newdata = data, # rast_stack arg
                    sample_vals = samples,
                    ref_density = ref_density,
                    xy_stats = xy_stats,
                    xy_penalty = xy_penalty,
                    radius_km = radius_km,
                    geographic = .is_lonlat(data),
                    bin_width = bin_width,
                    bin_num = bin_num,
                    offset = offset,
                    k_env = k_pred,
                    k_rs = k_obs,
                    confidence = confidence,
                    lambda = lambda,
                    exclude_slef = exclude_slef,
                    make_su = make_su,
                    num_threads = num_threads
                )
            },
            error = function(cond) {
                stop("HCAS benchmarking C++ function failed!\n", cond)
            }
        )
    } else if (.is_rast(data)) {
        # check terra is available
        .check_pkgs("terra")
        # check and convert to SpatRaster object
        data <- .check_rast(data)

        # sample extraction if needed
        if (ncol(samples) == 2) {
            cat("Extracting sample values...\n")
            samples <- cbind(samples, as.matrix(terra::extract(data, samples, ID = FALSE)))
        } else if ((ncol(samples) - 2) != terra::nlyr(data)) {
            stop("Sample feature count does not match number of raster layers.")
        }

        keep_features <- .keep_rs_features(drop_features, terra::nlyr(data) / 2L)
        samples <- .subset_rs_mat(samples, keep_features)
        data <- .subset_rs_rast(data, keep_features)

        tryCatch(
            {
                output <- terra::interpolate(
                    object = data,
                    model = list(),
                    fun = .benchmarking,
                    sample_vals = samples,
                    ref_density = ref_density,
                    xy_stats = xy_stats,
                    xy_penalty = xy_penalty,
                    radius_km = radius_km,
                    geographic = .is_lonlat(data),
                    bin_width = bin_width,
                    bin_num = bin_num,
                    offset = offset,
                    k_env = k_pred,
                    k_rs = k_obs,
                    confidence = confidence,
                    lambda = lambda,
                    exclude_slef = exclude_slef,
                    make_su = make_su,
                    num_threads = num_threads,
                    ...
                )
            },
            error = function(cond) {
                stop("HCAS benchmarking C++ function failed!\n", cond)
            }
        )

    } else {
        stop("The 'data' must be raster or a matrix, or convertiable object to these classes.")
    }

    return(
        output
    )
}


# a function to handling predicting with terra
.benchmarking <- function(model, newdata, make_su, ...){
    nr <- nrow(newdata)
    nc <- make_su + 1
    col_names <- c("condition", "su")[1:nc]

    dat <- as.matrix(newdata)

    tryCatch(
        {
            hcas_cond <- bench_cpp(
                raster_vals = dat,
                make_su = make_su,
                ...
            )
        },
        error = function(cond) {
            message("Benchmarking C++ function failed. Returning -0.02 for all cells.")
            # return error values -0.02
            return(
                matrix(-0.02, nrow = nr, ncol = nc, dimnames = list(NULL, col_names))
            )
        }
    )

    colnames(hcas_cond) <- col_names

    return(hcas_cond)
}

